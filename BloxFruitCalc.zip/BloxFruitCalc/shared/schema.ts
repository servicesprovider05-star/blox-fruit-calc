import { z } from "zod";

export const fruitSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(["Paramecia", "Logia", "Zoan"]),
  rarity: z.enum(["Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythical"]),
  value: z.number(),
  permanentValue: z.number(),
  demand: z.enum(["Low", "Medium", "High", "Very High"]),
  imageUrl: z.string(),
  description: z.string().optional(),
});

export const gamepassSchema = z.object({
  id: z.string(),
  name: z.string(),
  value: z.number(),
  description: z.string().optional(),
});

export const tradeItemSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("fruit"),
    fruit: fruitSchema,
    quantity: z.number().default(1),
  }),
  z.object({
    type: z.literal("gamepass"),
    gamepass: gamepassSchema,
    quantity: z.number().default(1),
  }),
]);

export const tradeSchema = z.object({
  yourOffer: z.array(tradeItemSchema),
  theirOffer: z.array(tradeItemSchema),
});

export type Fruit = z.infer<typeof fruitSchema>;
export type Gamepass = z.infer<typeof gamepassSchema>;
export type TradeItem = z.infer<typeof tradeItemSchema>;
export type Trade = z.infer<typeof tradeSchema>;

export const createInsertFruitSchema = fruitSchema.omit({ id: true });
export const createInsertGamepassSchema = gamepassSchema.omit({ id: true });

export type InsertFruit = z.infer<typeof createInsertFruitSchema>;
export type InsertGamepass = z.infer<typeof createInsertGamepassSchema>;
