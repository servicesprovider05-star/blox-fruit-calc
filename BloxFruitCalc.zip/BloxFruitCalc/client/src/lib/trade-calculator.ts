import { Trade, TradeItem } from "@shared/schema";

export interface TradeResult {
  yourValue: number;
  theirValue: number;
  difference: number;
  result: "W" | "L" | "Fair" | null;
}

export function calculateTradeResult(trade: Trade): TradeResult {
  const yourValue = calculateOfferValue(trade.yourOffer);
  const theirValue = calculateOfferValue(trade.theirOffer);
  const difference = theirValue - yourValue;

  let result: "W" | "L" | "Fair" | null = null;
  
  if (yourValue > 0 && theirValue > 0) {
    const percentageDifference = Math.abs(difference) / Math.max(yourValue, theirValue);
    
    if (percentageDifference <= 0.1) { // Within 10% is considered fair
      result = "Fair";
    } else if (difference > 0) {
      result = "W"; // You're getting more value
    } else {
      result = "L"; // You're giving more value
    }
  }

  return {
    yourValue,
    theirValue,
    difference,
    result,
  };
}

function calculateOfferValue(offer: TradeItem[]): number {
  return offer.reduce((total, item) => {
    const itemValue = item.type === "fruit" ? item.fruit.value : item.gamepass.value;
    return total + (itemValue * item.quantity);
  }, 0);
}

export function formatValue(value: number): string {
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  } else if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`;
  }
  return value.toString();
}
