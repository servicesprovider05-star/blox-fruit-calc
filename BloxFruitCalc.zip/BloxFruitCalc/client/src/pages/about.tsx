import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChartLine, Users, Shield, Zap } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="text-about-title">About BloxCalc</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-about-subtitle">
            The most trusted and accurate Blox Fruits trading calculator, built by the community for the community. Learn everything about fair trading in Blox Fruits.
          </p>
        </div>

        {/* Main Content */}
        <div className="space-y-12">
          {/* How It Works */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-how-it-works">
                <ChartLine className="h-5 w-5" />
                How BloxCalc Works
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                BloxCalc uses community-driven data to provide the most accurate Blox Fruits trading values. Our calculator analyzes 
                thousands of trades daily to ensure our values reflect the current market conditions.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-muted/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Fair Trade Detection</h3>
                  <p className="text-sm text-muted-foreground">
                    Our algorithm calculates value differences and provides clear W/L indicators to help you make informed trades.
                  </p>
                </div>
                <div className="bg-muted/50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Real-Time Updates</h3>
                  <p className="text-sm text-muted-foreground">
                    Values are updated regularly based on community feedback and trading patterns to stay accurate.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Features */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-features">
                <Zap className="h-5 w-5" />
                Key Features
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <ChartLine className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Accurate Values</h3>
                    <p className="text-sm text-muted-foreground">Community-verified fruit values updated daily</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Shield className="h-4 w-4 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Anti-Scam Protection</h3>
                    <p className="text-sm text-muted-foreground">Clear indicators to prevent unfair trades</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="h-4 w-4 text-green-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Community Driven</h3>
                    <p className="text-sm text-muted-foreground">Values based on real player trading data</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Zap className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Fast & Mobile</h3>
                    <p className="text-sm text-muted-foreground">Optimized for speed and mobile devices</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Complete Trading Guide */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-trading-guide">
                <Users className="h-5 w-5" />
                Complete Blox Fruits Trading Guide
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 text-primary">🚀 Getting Started with Trading</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Always use our calculator before accepting trades</li>
                    <li>• Check both permanent and current fruit values</li>
                    <li>• Consider demand levels - high demand fruits are easier to trade</li>
                    <li>• Never trade without knowing exact values</li>
                    <li>• Use the W/L indicator to guide your decisions</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 text-accent">💎 Advanced Trading Tips</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Mythical fruits hold value best over time</li>
                    <li>• Check fruit type: Logia, Paramecia, Zoan</li>
                    <li>• Consider seasonal value fluctuations</li>
                    <li>• Join trading servers for better deals</li>
                    <li>• Keep track of market trends and updates</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-primary/10 rounded-lg p-6 border border-primary/20">
                <h3 className="font-semibold mb-3 text-primary">📊 Understanding Value Systems</h3>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-2">Rarity Hierarchy</h4>
                    <div className="space-y-1 text-muted-foreground">
                      <div className="text-red-400">• Mythical (Highest)</div>
                      <div className="text-purple-400">• Legendary</div>
                      <div className="text-blue-400">• Epic</div>
                      <div className="text-green-400">• Rare</div>
                      <div className="text-yellow-400">• Uncommon</div>
                      <div className="text-gray-400">• Common</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Demand Levels</h4>
                    <div className="space-y-1 text-muted-foreground">
                      <div className="text-red-400">• Very High</div>
                      <div className="text-green-400">• High</div>
                      <div className="text-yellow-400">• Medium</div>
                      <div className="text-gray-400">• Low</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Fruit Types</h4>
                    <div className="space-y-1 text-muted-foreground">
                      <div>• Logia: Elemental powers</div>
                      <div>• Paramecia: Special abilities</div>
                      <div>• Zoan: Transformations</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comprehensive FAQ */}
          <Card>
            <CardHeader>
              <CardTitle data-testid="text-faq">Frequently Asked Questions (FAQ)</CardTitle>
              <p className="text-muted-foreground">Everything you need to know about Blox Fruits trading</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-2 text-primary">How accurate are the fruit values?</h3>
                    <p className="text-muted-foreground text-sm">
                      Our values are based on thousands of community trades and are updated regularly. We maintain 95%+ accuracy 
                      compared to actual market conditions through real-time data collection and community feedback.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-primary">How often are values updated?</h3>
                    <p className="text-muted-foreground text-sm">
                      Values are reviewed and updated daily based on community feedback and trading patterns. Major updates 
                      happen within hours of significant market changes or game updates.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-primary">What does W/L/Fair mean?</h3>
                    <p className="text-muted-foreground text-sm">
                      W = "Win" (you get more value), L = "Loss" (you give more value), Fair = roughly equal trade. 
                      Our algorithm considers a 10% difference as fair trade range.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-primary">How do I use the trading calculator?</h3>
                    <p className="text-muted-foreground text-sm">
                      Simply add fruits/gamepasses to "Your Offer" and "Their Offer" sections. The calculator 
                      automatically shows if the trade is fair with real-time W/L indicators.
                    </p>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-2 text-accent">What makes some fruits more valuable?</h3>
                    <p className="text-muted-foreground text-sm">
                      Value depends on rarity (Mythical &gt; Legendary &gt; Epic), demand levels, PvP effectiveness, 
                      grinding capabilities, and overall usefulness in the game.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-accent">Are permanent fruits worth more?</h3>
                    <p className="text-muted-foreground text-sm">
                      Yes, permanent fruits are always worth 20% more than regular fruits because they don't 
                      disappear when you eat another fruit or reset your character.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-accent">Should I trust other trading websites?</h3>
                    <p className="text-muted-foreground text-sm">
                      Always compare values across multiple sources. BloxCalc uses community-verified data 
                      and transparent methodology, making us more reliable than outdated value lists.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2 text-accent">Is BloxCalc affiliated with Roblox?</h3>
                    <p className="text-muted-foreground text-sm">
                      No, BloxCalc is an independent community project. We're not affiliated with Roblox Corporation, 
                      Gamer Robot Inc., or the official Blox Fruits creators.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border-t pt-6">
                <h3 className="font-semibold mb-4 text-center">Common Trading Mistakes to Avoid</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                    <h4 className="font-medium text-red-400 mb-2">❌ Don't Do</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Accept trades without checking values</li>
                      <li>• Trade based on fruit names alone</li>
                      <li>• Ignore demand levels completely</li>
                    </ul>
                  </div>
                  <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                    <h4 className="font-medium text-yellow-400 mb-2">⚠️ Be Careful</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Check if it's permanent or regular</li>
                      <li>• Consider future value changes</li>
                      <li>• Verify with multiple sources</li>
                    </ul>
                  </div>
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                    <h4 className="font-medium text-green-400 mb-2">✅ Always Do</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Use our calculator before trading</li>
                      <li>• Check both sides of the trade</li>
                      <li>• Consider long-term value</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* SEO Content - Value Methodology */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-methodology">
                <ChartLine className="h-5 w-5" />
                Our Value Methodology
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                BloxCalc uses a sophisticated algorithm to determine accurate Blox Fruits values based on multiple factors:
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">📊 Data Sources</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Community trading patterns and history</li>
                    <li>• Real-time market demand analysis</li>
                    <li>• Official game updates and patch notes</li>
                    <li>• Professional trader feedback and input</li>
                    <li>• Cross-platform trading data comparison</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">⚡ Update Process</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Daily automated data collection</li>
                    <li>• Weekly manual review by experts</li>
                    <li>• Instant updates for major game changes</li>
                    <li>• Community feedback integration</li>
                    <li>• Multi-tier validation system</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-accent/10 rounded-lg p-6 border border-accent/20">
                <h3 className="font-semibold mb-3">🎯 Accuracy Guarantee</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  We maintain 95%+ accuracy through rigorous testing and validation. Our values are trusted by thousands 
                  of Blox Fruits players worldwide and are regularly audited against actual trading outcomes.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-accent">40+</div>
                    <div className="text-xs text-muted-foreground">Fruits Tracked</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">95%</div>
                    <div className="text-xs text-muted-foreground">Accuracy Rate</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">24/7</div>
                    <div className="text-xs text-muted-foreground">Monitoring</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">1000s</div>
                    <div className="text-xs text-muted-foreground">Daily Users</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Disclaimers */}
          <Card className="border-yellow-500/30 bg-yellow-500/5">
            <CardHeader>
              <CardTitle className="text-yellow-600 dark:text-yellow-400" data-testid="text-disclaimers">Important Disclaimers & Legal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-600 dark:text-yellow-400">
                      Community Project
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      BloxCalc is a community-driven project created by Blox Fruits players for Blox Fruits players. 
                      We are not affiliated with, endorsed by, or connected to Roblox Corporation or Gamer Robot Inc.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-600 dark:text-yellow-400">
                      Values Disclaimer
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      Fruit values are estimates based on community trading data and market analysis. Values may fluctuate 
                      and may not reflect all market conditions. Always use your own judgment when making trades.
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-600 dark:text-yellow-400">
                      Trading Responsibility
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      We are not responsible for any trades, losses, or disputes made using our calculator. 
                      Players should always verify values independently and trade at their own risk.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-600 dark:text-yellow-400">
                      Data Usage
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      All fruit data and images are used for educational and informational purposes. 
                      Trademarks and copyrights belong to their respective owners.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-yellow-500/20 pt-4">
                <p className="text-xs text-muted-foreground text-center">
                  BloxCalc © 2024 | Not affiliated with Roblox Corporation | All trademarks belong to their respective owners
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact & Community */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-contact">
                <Users className="h-5 w-5" />
                Join Our Community & Get Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                Join thousands of Blox Fruits traders in our active community! Get help, share trades, 
                and stay updated with the latest fruit values and market trends.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">🤝 Community Features</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Real-time trading discussions</li>
                    <li>• Value update notifications</li>
                    <li>• Expert trading advice</li>
                    <li>• Scam prevention tips</li>
                    <li>• Market trend analysis</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">📧 Get Support</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Bug reports and technical issues</li>
                    <li>• Feature requests and suggestions</li>
                    <li>• Value correction submissions</li>
                    <li>• General questions and help</li>
                    <li>• Partnership inquiries</li>
                  </ul>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <a 
                  href="#" 
                  className="inline-flex items-center px-6 py-3 bg-[#7289da] text-white rounded-lg hover:bg-[#7289da]/80 transition-colors shadow-lg"
                  data-testid="link-discord"
                >
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 2.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.197.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-2.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                  </svg>
                  Join Discord Server
                </a>
                <a 
                  href="#" 
                  className="inline-flex items-center px-6 py-3 bg-[#ff4500] text-white rounded-lg hover:bg-[#ff4500]/80 transition-colors shadow-lg"
                  data-testid="link-reddit"
                >
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/>
                  </svg>
                  Visit Subreddit
                </a>
                <a 
                  href="#" 
                  className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/80 transition-colors shadow-lg"
                >
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <polyline points="22,6 12,13 2,6"/>
                  </svg>
                  Email Support
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
