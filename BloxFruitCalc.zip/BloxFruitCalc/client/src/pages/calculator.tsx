import TradingCalculator from "@/components/trading-calculator";

export default function Calculator() {
  return (
    <div className="min-h-screen bg-background">
      <div className="py-12 bg-gradient-to-br from-primary/10 via-background to-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="text-calculator-title">
            Trading Calculator
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-calculator-subtitle">
            Calculate fair trades instantly with accurate fruit values. Get real-time W/L indicators.
          </p>
        </div>
      </div>
      
      <TradingCalculator />
    </div>
  );
}
