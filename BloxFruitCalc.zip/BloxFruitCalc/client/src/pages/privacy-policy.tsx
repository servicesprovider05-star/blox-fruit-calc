import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Eye, Lock, AlertTriangle } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Privacy Policy</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Your privacy is important to us. This policy explains how BloxCalc collects, uses, and protects your information.
          </p>
          <div className="mt-4">
            <Badge variant="secondary">Last Updated: January 15, 2024</Badge>
          </div>
        </div>

        <div className="space-y-8">
          {/* Information We Collect */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Automatically Collected Information</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Browser type and version</li>
                  <li>• Operating system information</li>
                  <li>• IP address (anonymized)</li>
                  <li>• Pages visited and time spent</li>
                  <li>• Referring website information</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Usage Analytics</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Fruit search queries and preferences</li>
                  <li>• Calculator usage patterns</li>
                  <li>• Feature interaction data</li>
                  <li>• Error logs for troubleshooting</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Optional Information</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Community feedback and suggestions</li>
                  <li>• Email address (if you contact us)</li>
                  <li>• Discord username (if you join our server)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* How We Use Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                How We Use Your Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 text-primary">Service Improvement</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Enhance calculator accuracy</li>
                    <li>• Improve user experience</li>
                    <li>• Fix bugs and technical issues</li>
                    <li>• Develop new features</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 text-accent">Analytics & Insights</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Understand usage patterns</li>
                    <li>• Monitor site performance</li>
                    <li>• Generate anonymous statistics</li>
                    <li>• Prevent abuse and fraud</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Third-Party Services */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Third-Party Services
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Google Analytics</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  We use Google Analytics to understand how users interact with our website. This service may collect:
                </p>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Anonymized IP addresses</li>
                  <li>• Browser and device information</li>
                  <li>• Page views and user interactions</li>
                  <li>• Geographic location (country/region level)</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Google AdSense</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  We use Google AdSense to display advertisements. Google may use cookies to:
                </p>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Show relevant advertisements</li>
                  <li>• Measure ad performance</li>
                  <li>• Prevent fraud and abuse</li>
                  <li>• Provide aggregate reporting</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Content Delivery Networks</h3>
                <p className="text-muted-foreground text-sm">
                  We use CDNs to deliver images and content faster. These services may log basic request information.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Data Protection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Data Protection & Security
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Security Measures</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• HTTPS encryption for all traffic</li>
                    <li>• Secure data transmission</li>
                    <li>• Regular security audits</li>
                    <li>• Limited data collection</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Data Retention</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Analytics data: 26 months</li>
                    <li>• Error logs: 90 days</li>
                    <li>• User preferences: Until cleared</li>
                    <li>• Feedback: 2 years (anonymous)</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Your Rights */}
          <Card>
            <CardHeader>
              <CardTitle>Your Privacy Rights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">EU/UK Users (GDPR)</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Right to access your data</li>
                    <li>• Right to rectification</li>
                    <li>• Right to erasure</li>
                    <li>• Right to data portability</li>
                    <li>• Right to object to processing</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">California Users (CCPA)</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>• Right to know what data is collected</li>
                    <li>• Right to delete personal information</li>
                    <li>• Right to opt-out of sale</li>
                    <li>• Right to non-discrimination</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="font-semibold mb-2">How to Exercise Your Rights</h4>
                <p className="text-muted-foreground text-sm">
                  To exercise any of these rights, please contact us via email or Discord. 
                  We will respond within 30 days and may request verification of your identity.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Cookies */}
          <Card>
            <CardHeader>
              <CardTitle>Cookie Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-green-600 mb-2">Essential Cookies</h4>
                  <p className="text-muted-foreground text-sm">
                    Required for basic site functionality. Cannot be disabled.
                  </p>
                </div>
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-600 mb-2">Analytics Cookies</h4>
                  <p className="text-muted-foreground text-sm">
                    Help us understand site usage. Can be disabled in browser settings.
                  </p>
                </div>
                <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-purple-600 mb-2">Advertising Cookies</h4>
                  <p className="text-muted-foreground text-sm">
                    Used to show relevant ads. Can be controlled via ad preferences.
                  </p>
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p>
                  You can control cookies through your browser settings. However, disabling certain cookies 
                  may affect site functionality. For more information about cookies, visit 
                  <a href="https://www.allaboutcookies.org" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">
                    allaboutcookies.org
                  </a>.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact & Updates */}
          <Card>
            <CardHeader>
              <CardTitle>Contact & Policy Updates</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Contact Information</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  If you have questions about this privacy policy or want to exercise your rights:
                </p>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Email: privacy@bloxcalc.com</li>
                  <li>• Discord: Join our official server</li>
                  <li>• Response time: Within 72 hours</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Policy Updates</h3>
                <p className="text-muted-foreground text-sm">
                  We may update this privacy policy periodically. We will notify users of significant changes 
                  through our website banner and update the "Last Updated" date. Continued use of our service 
                  constitutes acceptance of the updated policy.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}