import { useQuery } from "@tanstack/react-query";
import { Fruit } from "@shared/schema";
import FruitCard from "@/components/fruit-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Download, BarChart3 } from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import Breadcrumb from "@/components/breadcrumb";
import DualValueDisplay from "@/components/dual-value-display";

export default function Values() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRarity, setSelectedRarity] = useState("All");
  const [sortBy, setSortBy] = useState("value");

  const { data: fruits = [], isLoading } = useQuery<Fruit[]>({
    queryKey: ["/api/fruits"],
  });

  const filteredAndSortedFruits = fruits
    .filter(fruit => {
      if (selectedRarity !== "All" && fruit.rarity !== selectedRarity) return false;
      if (searchQuery && !fruit.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "value":
          return b.value - a.value;
        case "name":
          return a.name.localeCompare(b.name);
        case "rarity":
          const rarityOrder = { "Mythical": 6, "Legendary": 5, "Epic": 4, "Rare": 3, "Uncommon": 2, "Common": 1 };
          return (rarityOrder[b.rarity as keyof typeof rarityOrder] || 0) - (rarityOrder[a.rarity as keyof typeof rarityOrder] || 0);
        default:
          return 0;
      }
    });

  const exportValues = () => {
    const dataStr = JSON.stringify(fruits, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'blox-fruits-values.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const rarityColors = {
    "Mythical": "bg-red-500/20 text-red-400 border-red-500/30",
    "Legendary": "bg-purple-500/20 text-purple-400 border-purple-500/30",
    "Epic": "bg-blue-500/20 text-blue-400 border-blue-500/30",
    "Rare": "bg-green-500/20 text-green-400 border-green-500/30",
    "Uncommon": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    "Common": "bg-gray-500/20 text-gray-400 border-gray-500/30"
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <Breadcrumb 
          items={[{ label: "Fruit Values" }]} 
          className="mb-6"
        />
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4" data-testid="text-values-title">Blox Fruits Values</h1>
          <p className="text-muted-foreground text-lg" data-testid="text-values-subtitle">
            Complete list of Blox Fruits values with rarity, demand, and market prices. Compare normal vs permanent values.
          </p>
        </div>

        {/* Filters and Controls */}
        <div className="bg-card border border-border rounded-xl p-6 mb-8">
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-4">
              {/* Rarity Filter */}
              <div className="flex gap-2">
                {["All", "Mythical", "Legendary", "Epic", "Rare"].map((rarity) => (
                  <Button
                    key={rarity}
                    variant={selectedRarity === rarity ? "default" : "secondary"}
                    size="sm"
                    onClick={() => setSelectedRarity(rarity)}
                    data-testid={`button-rarity-${rarity.toLowerCase()}`}
                  >
                    {rarity}
                  </Button>
                ))}
              </div>

              {/* Sort By */}
              <div className="flex gap-2">
                {[
                  { key: "value", label: "Value" },
                  { key: "name", label: "Name" },
                  { key: "rarity", label: "Rarity" }
                ].map(({ key, label }) => (
                  <Button
                    key={key}
                    variant={sortBy === key ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSortBy(key)}
                    data-testid={`button-sort-${key}`}
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              {/* Search */}
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search fruits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 w-64"
                  data-testid="input-search-values"
                />
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>

              {/* Export Button */}
              <Button onClick={exportValues} variant="outline" data-testid="button-export">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-accent" data-testid="stat-total-fruits">{fruits.length}</div>
            <div className="text-sm text-muted-foreground">Total Fruits</div>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-accent" data-testid="stat-mythical-count">
              {fruits.filter(f => f.rarity === "Mythical").length}
            </div>
            <div className="text-sm text-muted-foreground">Mythical</div>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-accent" data-testid="stat-legendary-count">
              {fruits.filter(f => f.rarity === "Legendary").length}
            </div>
            <div className="text-sm text-muted-foreground">Legendary</div>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-accent" data-testid="stat-highest-value">
              {Math.max(...fruits.map(f => f.value)).toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Highest Value</div>
          </div>
        </div>

        {/* Fruits Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {isLoading ? (
            Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-xl p-6 animate-pulse">
                <div className="w-full h-32 bg-muted rounded-lg mb-4" />
                <div className="h-4 bg-muted rounded mb-2" />
                <div className="h-3 bg-muted rounded mb-2" />
                <div className="h-3 bg-muted rounded" />
              </div>
            ))
          ) : filteredAndSortedFruits.length === 0 ? (
            <div className="col-span-full text-center py-12" data-testid="empty-state">
              <p className="text-muted-foreground text-lg">No fruits found matching your criteria</p>
            </div>
          ) : (
            filteredAndSortedFruits.map((fruit) => (
              <FruitCard key={fruit.id} fruit={fruit} />
            ))
          )}
        </div>

        {/* Results Count */}
        {!isLoading && (
          <div className="text-center mt-8 text-muted-foreground" data-testid="text-results-count">
            Showing {filteredAndSortedFruits.length} of {fruits.length} fruits
          </div>
        )}
      </div>
    </div>
  );
}
