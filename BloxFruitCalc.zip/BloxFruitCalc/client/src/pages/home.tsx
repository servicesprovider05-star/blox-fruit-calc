import Hero from "@/components/hero";
import TradingCalculator from "@/components/trading-calculator";
import { useQuery } from "@tanstack/react-query";
import { Fruit } from "@shared/schema";
import FruitCard from "@/components/fruit-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, ArrowRight, ChartLine, Smartphone, Shield } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRarity, setSelectedRarity] = useState("All");

  const { data: fruits = [], isLoading } = useQuery<Fruit[]>({
    queryKey: ["/api/fruits"],
  });

  const filteredFruits = fruits
    .filter(fruit => {
      if (selectedRarity !== "All" && fruit.rarity !== selectedRarity) return false;
      if (searchQuery && !fruit.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    })
    .slice(0, 8); // Show only 8 fruits on home page

  return (
    <div>
      <Hero />
      
      <TradingCalculator />
      
      {/* Popular Fruits Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold" data-testid="text-popular-fruits">Popular Fruits</h2>
            <Link href="/values">
              <Button variant="ghost" className="text-primary hover:text-primary/80" data-testid="link-view-all">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-8">
            {["All", "Mythical", "Legendary", "Epic"].map((rarity) => (
              <Button
                key={rarity}
                variant={selectedRarity === rarity ? "default" : "secondary"}
                onClick={() => setSelectedRarity(rarity)}
                data-testid={`button-filter-${rarity.toLowerCase()}`}
              >
                {rarity}
              </Button>
            ))}
            <div className="relative ml-auto">
              <Input
                type="text"
                placeholder="Search fruits..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 w-64"
                data-testid="input-search-fruits"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
          
          {/* Fruits Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-card border border-border rounded-xl p-6 animate-pulse">
                  <div className="w-full h-32 bg-muted rounded-lg mb-4" />
                  <div className="h-4 bg-muted rounded mb-2" />
                  <div className="h-3 bg-muted rounded mb-2" />
                  <div className="h-3 bg-muted rounded" />
                </div>
              ))
            ) : (
              filteredFruits.map((fruit) => (
                <FruitCard key={fruit.id} fruit={fruit} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-features-title">Why Choose BloxCalc?</h2>
            <p className="text-muted-foreground text-lg" data-testid="text-features-subtitle">The most accurate and trusted Blox Fruits trading calculator</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center" data-testid="feature-realtime-values">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <ChartLine className="text-primary h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Real-Time Values</h3>
              <p className="text-muted-foreground">Always up-to-date fruit values based on community trading data</p>
            </div>
            
            <div className="text-center" data-testid="feature-mobile-optimized">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Smartphone className="text-accent h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Mobile Optimized</h3>
              <p className="text-muted-foreground">Perfectly designed for mobile devices with touch-friendly interface</p>
            </div>
            
            <div className="text-center" data-testid="feature-anti-scam">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-green-500 h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Anti-Scam Protection</h3>
              <p className="text-muted-foreground">Clear W/L indicators help you avoid unfair trades</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <ChartLine className="text-primary-foreground h-4 w-4" />
                </div>
                <span className="text-xl font-bold">BloxCalc</span>
              </div>
              <p className="text-muted-foreground mb-4">
                The most accurate Blox Fruits trading calculator. Calculate fair trades and get real-time fruit values.
              </p>
              <p className="text-sm text-muted-foreground">
                ⚠️ Not affiliated with Roblox Corporation or Gamer Robot Inc.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link href="/" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Calculator
                </Link>
                <Link href="/values" className="block text-muted-foreground hover:text-foreground transition-colors">
                  Fruit Values
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-foreground transition-colors">
                  About
                </Link>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Community</h3>
              <div className="space-y-2">
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">Discord</a>
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">Reddit</a>
                <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">Twitter</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 BloxCalc. Community-driven fruit values. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
