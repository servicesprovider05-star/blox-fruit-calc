import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, AlertTriangle, Shield, Gavel } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Terms of Service</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Please read these terms carefully before using BloxCalc. By using our service, you agree to these terms.
          </p>
          <div className="mt-4">
            <Badge variant="secondary">Last Updated: January 15, 2024</Badge>
          </div>
        </div>

        <div className="space-y-8">
          {/* Acceptance of Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Acceptance of Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                By accessing and using BloxCalc ("the Service"), you accept and agree to be bound by the terms 
                and provisions of this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
              
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="font-semibold mb-2">What This Means</h4>
                <p className="text-muted-foreground text-sm">
                  Simply put: using our website means you agree to follow these rules. If you don't agree with them, 
                  please don't use BloxCalc.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Service Description */}
          <Card>
            <CardHeader>
              <CardTitle>Service Description</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">What BloxCalc Provides</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Blox Fruits trading value calculator</li>
                  <li>• Comprehensive fruit and gamepass database</li>
                  <li>• Fair trade indicators (W/L system)</li>
                  <li>• Market analysis and trading guides</li>
                  <li>• Public API for developers</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">What We Don't Provide</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Official Roblox or Blox Fruits endorsement</li>
                  <li>• Guarantee of trading success</li>
                  <li>• In-game items or currency</li>
                  <li>• Personal trading services</li>
                  <li>• Investment or financial advice</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* User Responsibilities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                User Responsibilities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 text-green-600">You May</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>✅ Use the calculator for personal trading</li>
                    <li>✅ Share our website with others</li>
                    <li>✅ Access our public API responsibly</li>
                    <li>✅ Provide feedback and suggestions</li>
                    <li>✅ Report bugs or issues</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 text-red-600">You May Not</h3>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li>❌ Copy or redistribute our content</li>
                    <li>❌ Reverse engineer our algorithms</li>
                    <li>❌ Use automated tools to scrape data</li>
                    <li>❌ Disrupt or overload our servers</li>
                    <li>❌ Attempt to hack or breach security</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Disclaimers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Important Disclaimers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-yellow-600 mb-2">Trading Risk Disclaimer</h4>
                  <p className="text-muted-foreground text-sm">
                    All trading involves risk. Our calculations are estimates based on community data and may not 
                    reflect current market conditions. Always verify values independently and trade at your own risk.
                  </p>
                </div>
                
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-600 mb-2">No Official Affiliation</h4>
                  <p className="text-muted-foreground text-sm">
                    BloxCalc is not affiliated with, endorsed by, or connected to Roblox Corporation, Gamer Robot Inc., 
                    or the creators of Blox Fruits. We are an independent community project.
                  </p>
                </div>
                
                <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-red-600 mb-2">Service Availability</h4>
                  <p className="text-muted-foreground text-sm">
                    We strive for 24/7 availability but cannot guarantee uninterrupted service. We may need to 
                    temporarily suspend service for maintenance, updates, or technical issues.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Intellectual Property */}
          <Card>
            <CardHeader>
              <CardTitle>Intellectual Property</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Our Content</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  BloxCalc owns the rights to:
                </p>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Website design and layout</li>
                  <li>• Trading calculator algorithms</li>
                  <li>• Original analysis and content</li>
                  <li>• API implementations</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Third-Party Content</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  We acknowledge that the following belong to their respective owners:
                </p>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Blox Fruits game content and imagery</li>
                  <li>• Roblox platform and branding</li>
                  <li>• Fruit names and game mechanics</li>
                  <li>• Official game assets and artwork</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Limitation of Liability */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gavel className="h-5 w-5" />
                Limitation of Liability
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-500/10 border border-gray-500/20 rounded-lg p-4">
                <h4 className="font-semibold mb-2">Service "As Is"</h4>
                <p className="text-muted-foreground text-sm">
                  BloxCalc is provided "as is" without warranties of any kind. We do not guarantee the accuracy 
                  of values, availability of service, or that the service will meet your specific needs.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">What We're Not Responsible For</h3>
                <ul className="text-muted-foreground text-sm space-y-1 ml-4">
                  <li>• Trading losses or bad trades</li>
                  <li>• Inaccurate value estimates</li>
                  <li>• Service downtime or interruptions</li>
                  <li>• Data loss or corruption</li>
                  <li>• Third-party website issues</li>
                  <li>• Game updates that affect values</li>
                </ul>
              </div>
              
              <p className="text-muted-foreground text-sm">
                In no event shall BloxCalc be liable for any indirect, incidental, special, consequential, 
                or punitive damages arising out of your use of the service.
              </p>
            </CardContent>
          </Card>

          {/* Modifications & Termination */}
          <Card>
            <CardHeader>
              <CardTitle>Modifications & Termination</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Service Changes</h3>
                  <p className="text-muted-foreground text-sm mb-2">We may:</p>
                  <ul className="text-muted-foreground text-sm space-y-1 ml-2">
                    <li>• Modify features and functionality</li>
                    <li>• Update our algorithms</li>
                    <li>• Change our pricing (if applicable)</li>
                    <li>• Add or remove content</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Terms Updates</h3>
                  <p className="text-muted-foreground text-sm mb-2">We may update these terms:</p>
                  <ul className="text-muted-foreground text-sm space-y-1 ml-2">
                    <li>• To comply with legal requirements</li>
                    <li>• To reflect service changes</li>
                    <li>• To improve clarity</li>
                    <li>• With 30 days notice for major changes</li>
                  </ul>
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Termination</h3>
                <p className="text-muted-foreground text-sm">
                  Either party may terminate this agreement at any time. We may suspend or terminate your access 
                  if you violate these terms. You may stop using our service at any time.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                If you have questions about these Terms of Service, please contact us:
              </p>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <h4 className="font-semibold mb-1">Email</h4>
                  <p className="text-muted-foreground text-sm">legal@bloxcalc.com</p>
                </div>
                <div className="text-center">
                  <h4 className="font-semibold mb-1">Discord</h4>
                  <p className="text-muted-foreground text-sm">Official BloxCalc Server</p>
                </div>
                <div className="text-center">
                  <h4 className="font-semibold mb-1">Response Time</h4>
                  <p className="text-muted-foreground text-sm">Within 72 hours</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}