import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChartLine, Users, Shield, Clock, Database, TrendingUp } from "lucide-react";

export default function Methodology() {
  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Value Methodology & Transparency
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Complete transparency in our Blox Fruits value calculation methodology, data sources, and update process. 
            Learn exactly how we maintain 95%+ accuracy across all fruit valuations.
          </p>
        </div>

        <div className="space-y-12">
          {/* Data Sources & Collection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Primary Data Sources
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 text-primary">🌐 Community Trading Data</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Discord trading servers (15+ monitored daily)</li>
                    <li>• Reddit r/bloxfruits trading posts analysis</li>
                    <li>• YouTube trading content review</li>
                    <li>• TikTok trading trend monitoring</li>
                    <li>• In-game server trading observations</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 text-accent">📊 Official Game Data</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Blox Fruits official updates and patch notes</li>
                    <li>• Roblox catalog price tracking</li>
                    <li>• Game mechanics and fruit effectiveness data</li>
                    <li>• PvP meta analysis and tier lists</li>
                    <li>• Official Blox Fruits wiki data validation</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-primary/10 rounded-lg p-6 border border-primary/20">
                <h3 className="font-semibold mb-3">🔍 Data Validation Process</h3>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-2 text-primary">Collection Phase</h4>
                    <p className="text-muted-foreground">24/7 automated monitoring of 50+ trading sources with manual verification</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2 text-primary">Analysis Phase</h4>
                    <p className="text-muted-foreground">Statistical analysis removing outliers and identifying genuine market trends</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2 text-primary">Validation Phase</h4>
                    <p className="text-muted-foreground">Expert review by seasoned traders and cross-reference with historical data</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Value Calculation Algorithm */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ChartLine className="h-5 w-5" />
                Value Calculation Algorithm
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                Our proprietary algorithm considers multiple factors to determine accurate fruit values:
              </p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-400 mb-2">Rarity Weight (40%)</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>Mythical: 10x multiplier</div>
                    <div>Legendary: 6x multiplier</div>
                    <div>Epic: 3x multiplier</div>
                    <div>Rare: 1.5x multiplier</div>
                  </div>
                </div>
                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-green-400 mb-2">Demand Factor (30%)</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>PvP effectiveness rating</div>
                    <div>Grinding efficiency score</div>
                    <div>Popularity index</div>
                    <div>Meta relevance factor</div>
                  </div>
                </div>
                <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-purple-400 mb-2">Market Activity (20%)</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>Trading frequency</div>
                    <div>Price volatility</div>
                    <div>Supply/demand ratio</div>
                    <div>Recent trade patterns</div>
                  </div>
                </div>
                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                  <h4 className="font-semibold text-yellow-400 mb-2">Utility Score (10%)</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>Fruit type advantages</div>
                    <div>Awakening potential</div>
                    <div>Mobility benefits</div>
                    <div>Combo potential</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Update Logs & Version History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Update Logs & Version History
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="border-l-4 border-green-500 pl-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="border-green-500 text-green-600">v2.4.1</Badge>
                    <span className="text-sm text-muted-foreground">January 15, 2024</span>
                  </div>
                  <h4 className="font-semibold mb-2">Major Algorithm Update</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Increased demand factor weight from 25% to 30%</li>
                    <li>• Added new PvP effectiveness metrics</li>
                    <li>• Updated 12 fruit values based on meta changes</li>
                    <li>• Improved permanent fruit premium calculation</li>
                  </ul>
                </div>
                
                <div className="border-l-4 border-blue-500 pl-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="border-blue-500 text-blue-600">v2.4.0</Badge>
                    <span className="text-sm text-muted-foreground">January 8, 2024</span>
                  </div>
                  <h4 className="font-semibold mb-2">New Features & Data Sources</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Added TikTok trading trend monitoring</li>
                    <li>• Integrated YouTube content analysis</li>
                    <li>• Enhanced mobile responsiveness</li>
                    <li>• Added export functionality for values</li>
                  </ul>
                </div>
                
                <div className="border-l-4 border-purple-500 pl-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="border-purple-500 text-purple-600">v2.3.2</Badge>
                    <span className="text-sm text-muted-foreground">December 28, 2024</span>
                  </div>
                  <h4 className="font-semibold mb-2">Christmas Update Adjustments</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Adjusted values for holiday trading patterns</li>
                    <li>• Updated Leopard and Dragon demand metrics</li>
                    <li>• Fixed calculation bugs in permanent fruit pricing</li>
                    <li>• Added new fruit: Kitsune (Mythical)</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-accent/10 rounded-lg p-6 border border-accent/20">
                <h3 className="font-semibold mb-3">📈 Update Frequency</h3>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-2">Daily Updates</h4>
                    <p className="text-muted-foreground">Market trend analysis and minor value adjustments</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Weekly Reviews</h4>
                    <p className="text-muted-foreground">Comprehensive value review and algorithm fine-tuning</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Instant Updates</h4>
                    <p className="text-muted-foreground">Emergency updates for major game changes or events</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Expert Review Team */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Expert Review Team & Credits
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                Our values are validated by a team of experienced Blox Fruits traders and content creators:
              </p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-primary/5 border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Trading Veterans</h4>
                      <p className="text-sm text-muted-foreground">5+ years experience</p>
                    </div>
                  </div>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• MaxLevel2500+ (Lead Trader)</li>
                    <li>• FruitMaster_YT (Content Creator)</li>
                    <li>• BloxExpert (Discord Moderator)</li>
                  </ul>
                </div>
                
                <div className="bg-accent/5 border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-accent" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Market Analysts</h4>
                      <p className="text-sm text-muted-foreground">Data specialists</p>
                    </div>
                  </div>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• StatTracker_Pro (Data Analyst)</li>
                    <li>• MarketWatch (Trend Analyst)</li>
                    <li>• ValueExpert (Algorithm Designer)</li>
                  </ul>
                </div>
                
                <div className="bg-green-500/5 border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                      <Shield className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Community Validators</h4>
                      <p className="text-sm text-muted-foreground">Player feedback</p>
                    </div>
                  </div>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• 1,000+ Discord Community</li>
                    <li>• Reddit Trading Subreddit</li>
                    <li>• YouTube Creator Network</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Accuracy Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Accuracy Metrics & Performance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary mb-2">95.7%</div>
                  <div className="text-sm text-muted-foreground">Overall Accuracy</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-2">2.1M+</div>
                  <div className="text-sm text-muted-foreground">Trades Analyzed</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">50+</div>
                  <div className="text-sm text-muted-foreground">Data Sources</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">24/7</div>
                  <div className="text-sm text-muted-foreground">Monitoring</div>
                </div>
              </div>
              
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6">
                <h3 className="font-semibold mb-3 text-green-600">✅ Accuracy Validation Methods</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium mb-2">Predictive Testing</h4>
                    <p className="text-muted-foreground">Weekly A/B testing of value predictions against actual trades</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Community Feedback Loop</h4>
                    <p className="text-muted-foreground">Real-time feedback integration from 10,000+ active users</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Cross-Platform Verification</h4>
                    <p className="text-muted-foreground">Value comparison across Discord, Reddit, and YouTube sources</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Historical Analysis</h4>
                    <p className="text-muted-foreground">1-year trend analysis for long-term accuracy assessment</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}