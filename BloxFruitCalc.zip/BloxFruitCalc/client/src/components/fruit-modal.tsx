import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Fruit } from "@shared/schema";

interface FruitModalProps {
  fruit: Fruit;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function FruitModal({ fruit, open, onOpenChange }: FruitModalProps) {
  const rarityColors = {
    "Mythical": "bg-red-500/20 text-red-400 border-red-500/30",
    "Legendary": "bg-purple-500/20 text-purple-400 border-purple-500/30",
    "Epic": "bg-blue-500/20 text-blue-400 border-blue-500/30",
    "Rare": "bg-green-500/20 text-green-400 border-green-500/30",
    "Uncommon": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    "Common": "bg-gray-500/20 text-gray-400 border-gray-500/30"
  };

  const demandColors = {
    "Very High": "text-red-400",
    "High": "text-green-400",
    "Medium": "text-yellow-400",
    "Low": "text-gray-400"
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid={`modal-fruit-${fruit.name.toLowerCase()}`}>
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span data-testid={`modal-title-${fruit.name.toLowerCase()}`}>
              {fruit.name} Details
            </span>
            <Badge 
              className={rarityColors[fruit.rarity as keyof typeof rarityColors]}
              data-testid={`modal-rarity-${fruit.name.toLowerCase()}`}
            >
              {fruit.rarity}
            </Badge>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <img 
            src={fruit.imageUrl} 
            alt={fruit.name}
            className="w-full h-48 object-cover rounded-lg"
            loading="lazy"
            data-testid={`modal-image-${fruit.name.toLowerCase()}`}
          />
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Current Value:</span>
              <span className="text-accent font-semibold" data-testid={`modal-value-${fruit.name.toLowerCase()}`}>
                {fruit.value.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Permanent Value:</span>
              <span className="text-accent" data-testid={`modal-permanent-${fruit.name.toLowerCase()}`}>
                {fruit.permanentValue.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Type:</span>
              <span className="text-foreground" data-testid={`modal-type-${fruit.name.toLowerCase()}`}>
                {fruit.type}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Demand:</span>
              <span 
                className={demandColors[fruit.demand as keyof typeof demandColors]}
                data-testid={`modal-demand-${fruit.name.toLowerCase()}`}
              >
                {fruit.demand}
              </span>
            </div>
          </div>
          
          {fruit.description && (
            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground" data-testid={`modal-description-${fruit.name.toLowerCase()}`}>
                {fruit.description}
              </p>
            </div>
          )}
          
          <Button 
            className="w-full" 
            onClick={() => onOpenChange(false)}
            data-testid={`modal-close-${fruit.name.toLowerCase()}`}
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
