import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Hero() {
  return (
    <section className="py-12 bg-gradient-to-br from-primary/10 via-background to-accent/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 
          className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
          data-testid="text-hero-title"
        >
          Blox Fruits Trading Calculator
        </h1>
        <p 
          className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
          data-testid="text-hero-subtitle"
        >
          Calculate fair trades instantly with our accurate fruit values. Get real-time W/L indicators and never get scammed again.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            className="px-8 py-3 font-semibold hover:scale-105 transition-all"
            size="lg"
            data-testid="button-start-trading"
          >
            Start Trading
          </Button>
          <Link href="/values">
            <Button 
              variant="secondary"
              size="lg"
              className="px-8 py-3 font-semibold hover:bg-secondary/80 transition-all"
              data-testid="button-view-values"
            >
              View All Values
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
