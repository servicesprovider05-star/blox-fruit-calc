import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, ArrowRight, Zap } from "lucide-react";

interface DualValueDisplayProps {
  fruitName: string;
  normalValue: number;
  permanentValue: number;
  rarity: string;
  demand: string;
  className?: string;
}

export default function DualValueDisplay({ 
  fruitName, 
  normalValue, 
  permanentValue, 
  rarity, 
  demand,
  className = ""
}: DualValueDisplayProps) {
  const premium = permanentValue - normalValue;
  const premiumPercentage = Math.round((premium / normalValue) * 100);
  
  const formatValue = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value.toLocaleString();
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case 'mythical': return 'text-red-400 border-red-400';
      case 'legendary': return 'text-purple-400 border-purple-400';
      case 'epic': return 'text-blue-400 border-blue-400';
      case 'rare': return 'text-green-400 border-green-400';
      case 'uncommon': return 'text-yellow-400 border-yellow-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const getDemandColor = (demand: string) => {
    switch (demand.toLowerCase()) {
      case 'very high': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'high': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <Card className={`group hover:shadow-lg transition-all duration-300 ${className}`}>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">{fruitName}</h3>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={getRarityColor(rarity)}>
                {rarity}
              </Badge>
              <Badge variant="outline" className={getDemandColor(demand)}>
                {demand}
              </Badge>
            </div>
          </div>

          {/* Value Comparison */}
          <div className="grid grid-cols-2 gap-4">
            {/* Normal Value */}
            <div className="text-center p-4 bg-muted/50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">Normal</div>
              <div className="text-2xl font-bold">{formatValue(normalValue)}</div>
              <div className="text-xs text-muted-foreground">Beli</div>
            </div>

            {/* Permanent Value */}
            <div className="text-center p-4 bg-primary/10 rounded-lg border border-primary/20">
              <div className="text-sm text-primary mb-1 flex items-center justify-center gap-1">
                <Zap className="h-3 w-3" />
                Permanent
              </div>
              <div className="text-2xl font-bold text-primary">{formatValue(permanentValue)}</div>
              <div className="text-xs text-primary/70">Beli</div>
            </div>
          </div>

          {/* Premium Calculation */}
          <div className="flex items-center justify-center gap-2 p-3 bg-accent/10 rounded-lg border border-accent/20">
            <TrendingUp className="h-4 w-4 text-accent" />
            <span className="text-sm text-muted-foreground">Premium:</span>
            <span className="font-semibold text-accent">+{formatValue(premium)}</span>
            <span className="text-sm text-muted-foreground">({premiumPercentage}%)</span>
          </div>

          {/* Value Flow Visualization */}
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <span>{formatValue(normalValue)}</span>
            <ArrowRight className="h-3 w-3" />
            <span className="text-primary font-medium">{formatValue(permanentValue)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}