import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Plus, X, RefreshCw } from "lucide-react";
import { Fruit, Gamepass, TradeItem } from "@shared/schema";
import { calculateTradeResult } from "@/lib/trade-calculator";

export default function TradingCalculator() {
  const [yourOffer, setYourOffer] = useState<TradeItem[]>([]);
  const [theirOffer, setTheirOffer] = useState<TradeItem[]>([]);
  const [yourSearchQuery, setYourSearchQuery] = useState("");
  const [theirSearchQuery, setTheirSearchQuery] = useState("");
  const [activeSection, setActiveSection] = useState<"your" | "their" | null>(null);
  const [yourSelectedRarity, setYourSelectedRarity] = useState("All");
  const [theirSelectedRarity, setTheirSelectedRarity] = useState("All");

  const { data: fruits = [] } = useQuery<Fruit[]>({
    queryKey: ["/api/fruits"],
  });

  const { data: gamepasses = [] } = useQuery<Gamepass[]>({
    queryKey: ["/api/gamepasses"],
  });

  const getFilteredItems = (searchQuery: string, selectedRarity: string) => {
    const filteredFruits = fruits.filter(fruit => {
      const matchesSearch = fruit.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRarity = selectedRarity === "All" || fruit.rarity === selectedRarity;
      return matchesSearch && matchesRarity;
    });

    const filteredGamepasses = gamepasses.filter(gamepass => 
      gamepass.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return [
      ...filteredFruits.map(fruit => ({ type: 'fruit' as const, item: fruit })),
      ...filteredGamepasses.map(gamepass => ({ type: 'gamepass' as const, item: gamepass }))
    ];
  };

  const addToOffer = (type: "your" | "their", itemType: "fruit" | "gamepass", item: Fruit | Gamepass) => {
    const tradeItem: TradeItem = itemType === "fruit" 
      ? { type: "fruit", fruit: item as Fruit, quantity: 1 }
      : { type: "gamepass", gamepass: item as Gamepass, quantity: 1 };

    if (type === "your") {
      setYourOffer(prev => [...prev, tradeItem]);
      setYourSearchQuery("");
    } else {
      setTheirOffer(prev => [...prev, tradeItem]);
      setTheirSearchQuery("");
    }
    setActiveSection(null);
  };

  const removeFromOffer = (type: "your" | "their", index: number) => {
    if (type === "your") {
      setYourOffer(prev => prev.filter((_, i) => i !== index));
    } else {
      setTheirOffer(prev => prev.filter((_, i) => i !== index));
    }
  };

  const clearAll = () => {
    setYourOffer([]);
    setTheirOffer([]);
    setYourSearchQuery("");
    setTheirSearchQuery("");
    setYourSelectedRarity("All");
    setTheirSelectedRarity("All");
    setActiveSection(null);
  };

  const tradeResult = calculateTradeResult({ yourOffer, theirOffer });

  const getResultBadge = () => {
    switch (tradeResult.result) {
      case "W":
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">WIN</Badge>;
      case "L":
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">LOSS</Badge>;
      case "Fair":
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">FAIR</Badge>;
      default:
        return <Badge variant="outline">-</Badge>;
    }
  };

  return (
    <section className="py-16 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="text-calculator-heading">Modern Trading Calculator</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto" data-testid="text-calculator-description">
            Select fruits and gamepasses from our comprehensive database to calculate fair trades instantly
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Your Offer */}
          <Card className="trade-box hover:shadow-xl transition-all border-2 hover:border-green-500/30" data-testid="card-your-offer">
            <CardHeader className="bg-gradient-to-r from-green-500/10 to-green-600/10 rounded-t-lg">
              <CardTitle className="text-green-400 flex items-center gap-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                Your Offer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 p-6">
              {/* Add Item Section */}
              {activeSection === "your" ? (
                <div className="space-y-4">
                  <div className="flex gap-2 mb-4">
                    {["All", "Mythical", "Legendary", "Epic", "Rare"].map((rarity) => (
                      <Button
                        key={rarity}
                        variant={yourSelectedRarity === rarity ? "default" : "outline"}
                        size="sm"
                        onClick={() => setYourSelectedRarity(rarity)}
                        data-testid={`button-your-rarity-${rarity.toLowerCase()}`}
                      >
                        {rarity}
                      </Button>
                    ))}
                  </div>
                  
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search fruits and gamepasses..."
                      value={yourSearchQuery}
                      onChange={(e) => setYourSearchQuery(e.target.value)}
                      className="pr-12"
                      data-testid="input-search-your"
                    />
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                  
                  <div className="max-h-64 overflow-y-auto space-y-1 border rounded-lg p-2 bg-card/50">
                    {getFilteredItems(yourSearchQuery, yourSelectedRarity).map((item, index) => (
                      <button
                        key={`${item.type}-${item.item.id}`}
                        className="w-full text-left p-3 rounded-lg hover:bg-primary/10 transition-colors flex items-center gap-3 border border-transparent hover:border-primary/30"
                        onClick={() => addToOffer("your", item.type, item.item)}
                        data-testid={`button-add-${item.item.name.toLowerCase()}`}
                      >
                        <img 
                          src={item.type === 'fruit' ? (item.item as Fruit).imageUrl : '/gamepass-icon.png'} 
                          alt={item.item.name}
                          className="w-10 h-10 rounded-lg object-cover"
                          loading="lazy"
                        />
                        <div className="flex-1">
                          <div className="font-medium text-foreground">{item.item.name}</div>
                          <div className="text-sm text-accent font-semibold">
                            {item.item.value.toLocaleString()}
                          </div>
                          {item.type === 'fruit' && (
                            <div className="text-xs text-muted-foreground">
                              {(item.item as Fruit).rarity} • {(item.item as Fruit).demand} Demand
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                    {getFilteredItems(yourSearchQuery, yourSelectedRarity).length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No items found
                      </div>
                    )}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => setActiveSection(null)}
                    className="w-full"
                    data-testid="button-cancel-add"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <>
                  {/* Selected Items */}
                  <div className="space-y-3 min-h-[300px]">
                    {yourOffer.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-center py-16">
                        <div>
                          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Plus className="w-8 h-8 text-green-400" />
                          </div>
                          <p className="text-muted-foreground">Add items to your offer</p>
                        </div>
                      </div>
                    ) : (
                      yourOffer.map((tradeItem, index) => (
                        <div key={index} className="flex items-center bg-secondary/50 rounded-xl p-4 border hover:bg-secondary/70 transition-colors" data-testid={`item-your-${index}`}>
                          <img 
                            src={tradeItem.type === 'fruit' ? tradeItem.fruit.imageUrl : '/gamepass-icon.png'} 
                            alt={tradeItem.type === 'fruit' ? tradeItem.fruit.name : tradeItem.gamepass.name}
                            className="w-12 h-12 rounded-lg object-cover mr-3"
                            loading="lazy"
                          />
                          <div className="flex-1">
                            <div className="font-semibold text-foreground">
                              {tradeItem.type === 'fruit' ? tradeItem.fruit.name : tradeItem.gamepass.name}
                            </div>
                            <div className="text-sm text-accent font-medium">
                              {(tradeItem.type === 'fruit' ? tradeItem.fruit.value : tradeItem.gamepass.value).toLocaleString()}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFromOffer("your", index)}
                            className="text-destructive hover:text-destructive/80 hover:bg-destructive/10 p-2"
                            data-testid={`button-remove-your-${index}`}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                  
                  <Button
                    variant="outline"
                    className="w-full border-dashed border-2 hover:border-green-400 hover:bg-green-500/5 transition-all py-6"
                    onClick={() => setActiveSection("your")}
                    data-testid="button-add-your"
                  >
                    <Plus className="mr-2 h-5 w-5" />
                    Add Items to Your Offer
                  </Button>
                </>
              )}
              
              <div className="pt-4 border-t border-border">
                <div className="text-xl font-bold text-foreground flex justify-between items-center" data-testid="text-your-total">
                  <span>Total Value:</span>
                  <span className="text-green-400">{tradeResult.yourValue.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Trade Result */}
          <div className="flex flex-col justify-center items-center space-y-6">
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-lg">
                <RefreshCw className="text-primary-foreground h-10 w-10" />
              </div>
              <div className="absolute -inset-2 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full animate-ping" />
            </div>
            
            <Card className="text-center min-w-[250px] border-2 shadow-xl" data-testid="trade-result">
              <CardContent className="p-8">
                <div className="mb-6">
                  {getResultBadge()}
                </div>
                <div className="text-3xl font-bold mb-4 bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent" data-testid="text-result-label">
                  {tradeResult.result === "W" && "YOU WIN! 🎉"}
                  {tradeResult.result === "L" && "YOU LOSE 😔"}
                  {tradeResult.result === "Fair" && "FAIR TRADE ⚖️"}
                  {!tradeResult.result && "ADD ITEMS 👆"}
                </div>
                <div className="text-lg font-medium text-muted-foreground" data-testid="text-result-difference">
                  {tradeResult.difference !== 0 && (
                    <>Difference: <span className={tradeResult.difference > 0 ? "text-green-400" : "text-red-400"}>{tradeResult.difference > 0 ? "+" : ""}{tradeResult.difference.toLocaleString()}</span></>
                  )}
                  {tradeResult.difference === 0 && yourOffer.length > 0 && theirOffer.length > 0 && (
                    <span className="text-yellow-400">Perfect Match!</span>
                  )}
                </div>
              </CardContent>
            </Card>
            
            <div className="flex gap-4">
              <Button 
                onClick={clearAll} 
                variant="outline"
                className="px-6"
                data-testid="button-clear-all"
              >
                Clear All
              </Button>
              {(yourOffer.length > 0 || theirOffer.length > 0) && (
                <Button 
                  variant="secondary"
                  className="px-6"
                >
                  Share Trade
                </Button>
              )}
            </div>
          </div>
          
          {/* Their Offer */}
          <Card className="trade-box hover:shadow-xl transition-all border-2 hover:border-blue-500/30" data-testid="card-their-offer">
            <CardHeader className="bg-gradient-to-r from-blue-500/10 to-blue-600/10 rounded-t-lg">
              <CardTitle className="text-blue-400 flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse" />
                Their Offer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 p-6">
              {/* Add Item Section */}
              {activeSection === "their" ? (
                <div className="space-y-4">
                  <div className="flex gap-2 mb-4">
                    {["All", "Mythical", "Legendary", "Epic", "Rare"].map((rarity) => (
                      <Button
                        key={rarity}
                        variant={theirSelectedRarity === rarity ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheirSelectedRarity(rarity)}
                        data-testid={`button-their-rarity-${rarity.toLowerCase()}`}
                      >
                        {rarity}
                      </Button>
                    ))}
                  </div>
                  
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search fruits and gamepasses..."
                      value={theirSearchQuery}
                      onChange={(e) => setTheirSearchQuery(e.target.value)}
                      className="pr-12"
                      data-testid="input-search-their"
                    />
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                  
                  <div className="max-h-64 overflow-y-auto space-y-1 border rounded-lg p-2 bg-card/50">
                    {getFilteredItems(theirSearchQuery, theirSelectedRarity).map((item, index) => (
                      <button
                        key={`${item.type}-${item.item.id}`}
                        className="w-full text-left p-3 rounded-lg hover:bg-primary/10 transition-colors flex items-center gap-3 border border-transparent hover:border-primary/30"
                        onClick={() => addToOffer("their", item.type, item.item)}
                        data-testid={`button-add-their-${item.item.name.toLowerCase()}`}
                      >
                        <img 
                          src={item.type === 'fruit' ? (item.item as Fruit).imageUrl : '/gamepass-icon.png'} 
                          alt={item.item.name}
                          className="w-10 h-10 rounded-lg object-cover"
                          loading="lazy"
                        />
                        <div className="flex-1">
                          <div className="font-medium text-foreground">{item.item.name}</div>
                          <div className="text-sm text-accent font-semibold">
                            {item.item.value.toLocaleString()}
                          </div>
                          {item.type === 'fruit' && (
                            <div className="text-xs text-muted-foreground">
                              {(item.item as Fruit).rarity} • {(item.item as Fruit).demand} Demand
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                    {getFilteredItems(theirSearchQuery, theirSelectedRarity).length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No items found
                      </div>
                    )}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => setActiveSection(null)}
                    className="w-full"
                    data-testid="button-cancel-add-their"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <>
                  {/* Selected Items */}
                  <div className="space-y-3 min-h-[300px]">
                    {theirOffer.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-center py-16">
                        <div>
                          <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Plus className="w-8 h-8 text-blue-400" />
                          </div>
                          <p className="text-muted-foreground">Add items to their offer</p>
                        </div>
                      </div>
                    ) : (
                      theirOffer.map((tradeItem, index) => (
                        <div key={index} className="flex items-center bg-secondary/50 rounded-xl p-4 border hover:bg-secondary/70 transition-colors" data-testid={`item-their-${index}`}>
                          <img 
                            src={tradeItem.type === 'fruit' ? tradeItem.fruit.imageUrl : '/gamepass-icon.png'} 
                            alt={tradeItem.type === 'fruit' ? tradeItem.fruit.name : tradeItem.gamepass.name}
                            className="w-12 h-12 rounded-lg object-cover mr-3"
                            loading="lazy"
                          />
                          <div className="flex-1">
                            <div className="font-semibold text-foreground">
                              {tradeItem.type === 'fruit' ? tradeItem.fruit.name : tradeItem.gamepass.name}
                            </div>
                            <div className="text-sm text-accent font-medium">
                              {(tradeItem.type === 'fruit' ? tradeItem.fruit.value : tradeItem.gamepass.value).toLocaleString()}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFromOffer("their", index)}
                            className="text-destructive hover:text-destructive/80 hover:bg-destructive/10 p-2"
                            data-testid={`button-remove-their-${index}`}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                  
                  <Button
                    variant="outline"
                    className="w-full border-dashed border-2 hover:border-blue-400 hover:bg-blue-500/5 transition-all py-6"
                    onClick={() => setActiveSection("their")}
                    data-testid="button-add-their"
                  >
                    <Plus className="mr-2 h-5 w-5" />
                    Add Items to Their Offer
                  </Button>
                </>
              )}
              
              <div className="pt-4 border-t border-border">
                <div className="text-xl font-bold text-foreground flex justify-between items-center" data-testid="text-their-total">
                  <span>Total Value:</span>
                  <span className="text-blue-400">{tradeResult.theirValue.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
