import { Link } from "wouter";
import { Calculator, Heart, ExternalLink } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Calculator className="text-primary-foreground h-4 w-4" />
              </div>
              <span className="text-xl font-bold">BloxCalc</span>
            </div>
            <p className="text-muted-foreground text-sm">
              The most trusted Blox Fruits trading calculator. Get accurate values, fair trade indicators, 
              and never get scammed again.
            </p>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>Made with</span>
              <Heart className="h-3 w-3 text-red-500" />
              <span>by the community</span>
            </div>
          </div>

          {/* Navigation */}
          <div className="space-y-4">
            <h3 className="font-semibold">Navigation</h3>
            <div className="space-y-2">
              <Link href="/" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                Trading Calculator
              </Link>
              <Link href="/values" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                Fruit Values
              </Link>
              <Link href="/methodology" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                Our Methodology
              </Link>
              <Link href="/about" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                About & FAQ
              </Link>
            </div>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h3 className="font-semibold">Resources</h3>
            <div className="space-y-2">
              <Link href="/api/public/data" className="flex items-center gap-1 text-muted-foreground text-sm hover:text-foreground transition-colors">
                Public API
                <ExternalLink className="h-3 w-3" />
              </Link>
              <Link href="/api/values/comparison" className="flex items-center gap-1 text-muted-foreground text-sm hover:text-foreground transition-colors">
                Value Comparison
                <ExternalLink className="h-3 w-3" />
              </Link>
              <Link href="/api/sitemap.xml" className="flex items-center gap-1 text-muted-foreground text-sm hover:text-foreground transition-colors">
                Sitemap
                <ExternalLink className="h-3 w-3" />
              </Link>
              <a href="https://discord.gg/bloxcalc" className="flex items-center gap-1 text-muted-foreground text-sm hover:text-foreground transition-colors" target="_blank" rel="noopener noreferrer">
                Discord Server
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h3 className="font-semibold">Legal & Privacy</h3>
            <div className="space-y-2">
              <Link href="/privacy-policy" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms-of-service" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                Terms of Service
              </Link>
              <a href="/ads.txt" className="block text-muted-foreground text-sm hover:text-foreground transition-colors" target="_blank">
                Ads.txt
              </a>
              <a href="/robots.txt" className="block text-muted-foreground text-sm hover:text-foreground transition-colors" target="_blank">
                Robots.txt
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-8 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-muted-foreground text-sm">
              © 2024 BloxCalc. All rights reserved. Not affiliated with Roblox Corporation.
            </div>
            <div className="flex items-center space-x-6 text-xs text-muted-foreground">
              <span>Version 2.4.1</span>
              <span>•</span>
              <span>40+ Fruits Tracked</span>
              <span>•</span>
              <span>95% Accuracy Rate</span>
              <span>•</span>
              <span>24/7 Monitoring</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}