import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Fruit } from "@shared/schema";
import { useState } from "react";
import FruitModal from "./fruit-modal";

interface FruitCardProps {
  fruit: Fruit;
}

export default function FruitCard({ fruit }: FruitCardProps) {
  const [modalOpen, setModalOpen] = useState(false);

  const rarityColors = {
    "Mythical": "bg-red-500/20 text-red-400 border-red-500/30",
    "Legendary": "bg-purple-500/20 text-purple-400 border-purple-500/30",
    "Epic": "bg-blue-500/20 text-blue-400 border-blue-500/30",
    "Rare": "bg-green-500/20 text-green-400 border-green-500/30",
    "Uncommon": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    "Common": "bg-gray-500/20 text-gray-400 border-gray-500/30"
  };

  const demandColors = {
    "Very High": "text-red-400",
    "High": "text-green-400",
    "Medium": "text-yellow-400",
    "Low": "text-gray-400"
  };

  return (
    <>
      <Card 
        className="fruit-card hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer"
        onClick={() => setModalOpen(true)}
        data-testid={`card-fruit-${fruit.name.toLowerCase()}`}
      >
        <CardContent className="p-6">
          <img 
            src={fruit.imageUrl} 
            alt={fruit.name}
            className="w-full h-32 object-cover rounded-lg mb-4"
            loading="lazy"
          />
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-semibold text-lg text-foreground" data-testid={`text-fruit-name-${fruit.name.toLowerCase()}`}>
              {fruit.name}
            </h3>
            <Badge 
              className={`text-xs ${rarityColors[fruit.rarity as keyof typeof rarityColors]}`}
              data-testid={`badge-rarity-${fruit.name.toLowerCase()}`}
            >
              {fruit.rarity}
            </Badge>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Value:</span>
              <span className="text-accent font-medium" data-testid={`text-value-${fruit.name.toLowerCase()}`}>
                {fruit.value.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Demand:</span>
              <span 
                className={demandColors[fruit.demand as keyof typeof demandColors]}
                data-testid={`text-demand-${fruit.name.toLowerCase()}`}
              >
                {fruit.demand}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Type:</span>
              <span className="text-muted-foreground" data-testid={`text-type-${fruit.name.toLowerCase()}`}>
                {fruit.type}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <FruitModal 
        fruit={fruit} 
        open={modalOpen} 
        onOpenChange={setModalOpen}
      />
    </>
  );
}
