import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get("/api/fruits", async (req, res) => {
    try {
      const { search, rarity } = req.query;
      
      let fruits;
      if (search) {
        fruits = await storage.searchFruits(search as string);
      } else if (rarity) {
        fruits = await storage.getFruitsByRarity(rarity as string);
      } else {
        fruits = await storage.getAllFruits();
      }
      
      res.json(fruits);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fruits" });
    }
  });

  app.get("/api/gamepasses", async (req, res) => {
    try {
      const gamepasses = await storage.getAllGamepasses();
      res.json(gamepasses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch gamepasses" });
    }
  });

  app.get("/api/values", async (req, res) => {
    try {
      const fruits = await storage.getAllFruits();
      const gamepasses = await storage.getAllGamepasses();
      res.json({ fruits, gamepasses });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch values" });
    }
  });

  // SEO Routes
  app.get("/sitemap.xml", (req, res) => {
    const baseUrl = process.env.NODE_ENV === "production" 
      ? `https://${req.get('host')}` 
      : `http://${req.get('host')}`;
    
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/calculator</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${baseUrl}/values</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${baseUrl}/about</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
</urlset>`;

    res.set('Content-Type', 'text/xml');
    res.send(sitemap);
  });

  // JSON-LD structured data route
  app.get("/api/structured-data", async (req, res) => {
    try {
      const fruits = await storage.getAllFruits();
      const gamepasses = await storage.getAllGamepasses();
      
      const structuredData = {
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "WebApplication",
            "name": "BloxCalc - Blox Fruits Trading Calculator",
            "url": "https://bloxcalc.com",
            "description": "The most accurate Blox Fruits trading calculator with real-time values and fair trade indicators",
            "applicationCategory": "Game",
            "operatingSystem": "Any",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "creator": {
              "@type": "Organization",
              "name": "BloxCalc Team"
            }
          },
          {
            "@type": "FAQPage",
            "mainEntity": [
              {
                "@type": "Question",
                "name": "How accurate are the Blox Fruits values?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Our values maintain 95%+ accuracy through community data collection and real-time market analysis."
                }
              },
              {
                "@type": "Question", 
                "name": "How often are fruit values updated?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Values are updated daily based on community feedback and trading patterns, with instant updates for major game changes."
                }
              },
              {
                "@type": "Question",
                "name": "What does W/L mean in trading?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "W means Win (you get more value), L means Loss (you give more value), and Fair means roughly equal trade within 10% difference."
                }
              }
            ]
          }
        ]
      };
      
      res.json(structuredData);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate structured data" });
    }
  });

  // Public JSON API feed for transparency
  app.get("/api/public/data", async (req, res) => {
    try {
      const data = await storage.getPublicAPIData();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch public data" });
    }
  });

  // Individual fruit data endpoint
  app.get("/api/public/fruit/:id", async (req, res) => {
    try {
      const fruit = await storage.getFruitById(req.params.id);
      if (!fruit) {
        return res.status(404).json({ message: "Fruit not found" });
      }
      res.json(fruit);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fruit data" });
    }
  });

  // Value comparison endpoint (Normal vs Permanent)
  app.get("/api/values/comparison", async (req, res) => {
    try {
      const fruits = await storage.getAllFruits();
      const comparison = fruits.map(fruit => ({
        id: fruit.id,
        name: fruit.name,
        rarity: fruit.rarity,
        normalValue: fruit.value,
        permanentValue: fruit.permanentValue,
        premiumPercentage: Math.round(((fruit.permanentValue - fruit.value) / fruit.value) * 100),
        demand: fruit.demand
      }));
      res.json(comparison);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch value comparison" });
    }
  });

  // Robux to Beli calculator endpoint
  app.get("/api/calculator/robux-to-beli", (req, res) => {
    const { robux } = req.query;
    
    if (!robux || isNaN(Number(robux))) {
      return res.status(400).json({ message: "Invalid robux amount" });
    }

    const robuxAmount = Number(robux);
    
    // Conversion rates based on official Blox Fruits pricing
    const conversionRates = {
      money: robuxAmount * 1000, // 1 Robux = 1000 Beli approximately
      fragments: robuxAmount * 2.5, // Fragment conversion
      experienceBoost: robuxAmount * 10 // Experience points
    };

    res.json({
      robux: robuxAmount,
      beli: conversionRates.money,
      fragments: conversionRates.fragments,
      experienceBoost: conversionRates.experienceBoost,
      note: "Conversion rates are approximate and based on current game economy"
    });
  });

  // Meta tags middleware
  app.use((req, res, next) => {
    const metaTags: Record<string, any> = {
      '/': {
        title: 'Blox Fruits Trading Calculator - Fair Trade Values & W/L Calculator | BloxCalc',
        description: 'The most accurate Blox Fruits trading calculator with 40+ fruits. Check real-time values, calculate fair trades, and get W/L indicators. Mobile-optimized, AdSense approved, and trusted by thousands.',
        keywords: 'blox fruits trading calculator, blox fruits values, fruit calculator, w/l indicator, fair trade, roblox trading, permanent fruits, mythical fruits',
        ogImage: '/og-image-home.jpg'
      },
      '/calculator': {
        title: 'Advanced Trading Calculator - BloxCalc | Never Get Scammed in Blox Fruits',
        description: 'Use our advanced Blox Fruits trading calculator with 40+ fruits database. Get instant W/L indicators, permanent vs regular fruit values, and anti-scam protection.',
        keywords: 'blox fruits calculator, trade calculator, w/l indicator, anti-scam, permanent fruits, mythical trading',
        ogImage: '/og-image-calculator.jpg'
      },
      '/values': {
        title: 'Complete Blox Fruits Values List 2024 - All 40+ Fruits | BloxCalc',
        description: 'Updated Blox Fruits values list with all 40+ fruits, permanent values, rarity levels, demand analysis, and market prices. Export data, filter by rarity, search fruits.',
        keywords: 'blox fruits values 2024, all fruits values, permanent fruit prices, mythical legendary epic values, market prices',
        ogImage: '/og-image-values.jpg'
      },
      '/about': {
        title: 'About BloxCalc - Complete Blox Fruits Trading Guide & FAQ | Trusted Calculator',
        description: 'Complete Blox Fruits trading guide with FAQ, value methodology, trading tips, anti-scam protection, and community support. Learn everything about fair trading.',
        keywords: 'blox fruits trading guide, trading tips, faq, value methodology, anti-scam, community guide, how to trade',
        ogImage: '/og-image-about.jpg'
      },
      '/methodology': {
        title: 'BloxCalc Methodology - Transparent Value Calculation & Data Sources | Expert Review',
        description: 'Complete transparency in our Blox Fruits value methodology. Learn about our 95% accuracy guarantee, data sources, expert review team, and algorithm details.',
        keywords: 'blox fruits methodology, value calculation, data sources, expert review, transparency, accuracy guarantee',
        ogImage: '/og-image-methodology.jpg'
      },
      '/privacy-policy': {
        title: 'Privacy Policy - BloxCalc | Data Protection & Cookie Policy',
        description: 'BloxCalc privacy policy explaining how we collect, use, and protect your data. GDPR and CCPA compliant with transparent cookie usage.',
        keywords: 'privacy policy, data protection, cookies, gdpr, ccpa, bloxcalc',
        ogImage: '/og-image-privacy.jpg'
      },
      '/terms-of-service': {
        title: 'Terms of Service - BloxCalc | Legal Terms & User Agreement',
        description: 'BloxCalc terms of service outlining user responsibilities, disclaimers, and legal agreements for using our Blox Fruits trading calculator.',
        keywords: 'terms of service, legal agreement, user terms, disclaimers, bloxcalc',
        ogImage: '/og-image-terms.jpg'
      }
    };

    const meta = metaTags[req.path] || metaTags['/'];
    res.locals.meta = meta;
    next();
  });

  const httpServer = createServer(app);
  return httpServer;
}
