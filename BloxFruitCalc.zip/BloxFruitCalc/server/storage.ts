import { type Fruit, type Gamepass } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllFruits(): Promise<Fruit[]>;
  getFruitById(id: string): Promise<Fruit | undefined>;
  getAllGamepasses(): Promise<Gamepass[]>;
  getGamepassById(id: string): Promise<Gamepass | undefined>;
  searchFruits(query: string): Promise<Fruit[]>;
  getFruitsByRarity(rarity: string): Promise<Fruit[]>;
  getPublicAPIData(): Promise<{ fruits: Fruit[], gamepasses: Gamepass[], lastUpdated: string, version: string }>;
}

export class MemStorage implements IStorage {
  private fruits: Map<string, Fruit>;
  private gamepasses: Map<string, Gamepass>;

  constructor() {
    this.fruits = new Map();
    this.gamepasses = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize fruits data - 40+ fruits for comprehensive database
    const fruitsData: Omit<Fruit, 'id'>[] = [
      // Mythical Fruits
      {
        name: "Leopard",
        type: "Zoan",
        rarity: "Mythical",
        value: 5000000,
        permanentValue: 6000000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=400&fit=crop",
        description: "The most valuable mythical Zoan fruit with incredible speed and power."
      },
      {
        name: "Dragon",
        type: "Zoan",
        rarity: "Mythical",
        value: 3500000,
        permanentValue: 4200000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop",
        description: "A powerful mythical Zoan fruit that transforms the user into a dragon."
      },
      {
        name: "Control",
        type: "Paramecia",
        rarity: "Mythical",
        value: 3200000,
        permanentValue: 3840000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A powerful mythical fruit with gravitational control."
      },
      {
        name: "Venom",
        type: "Logia",
        rarity: "Mythical",
        value: 3000000,
        permanentValue: 3600000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop",
        description: "A deadly mythical Logia fruit with poisonous abilities."
      },
      {
        name: "Shadow",
        type: "Paramecia",
        rarity: "Mythical",
        value: 2900000,
        permanentValue: 3480000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=400&fit=crop",
        description: "A mysterious mythical fruit that controls shadows."
      },
      {
        name: "Dough",
        type: "Paramecia",
        rarity: "Mythical",
        value: 2800000,
        permanentValue: 3360000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400&h=400&fit=crop",
        description: "A versatile mythical Paramecia fruit with elastic properties."
      },
      {
        name: "Soul",
        type: "Paramecia",
        rarity: "Mythical",
        value: 2700000,
        permanentValue: 3240000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A mythical fruit that manipulates souls and life force."
      },
      {
        name: "Spirit",
        type: "Logia",
        rarity: "Mythical",
        value: 3400000,
        permanentValue: 4080000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=400&fit=crop",
        description: "A mythical Logia fruit that controls spiritual energy."
      },
      {
        name: "T-Rex",
        type: "Zoan",
        rarity: "Mythical",
        value: 2700000,
        permanentValue: 3240000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=400&fit=crop",
        description: "A powerful mythical Zoan that transforms into a T-Rex."
      },
      {
        name: "Mammoth",
        type: "Zoan",
        rarity: "Mythical",
        value: 2700000,
        permanentValue: 3240000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=400&fit=crop",
        description: "A mythical Zoan fruit that grants mammoth transformation."
      },
      
      // Legendary Fruits
      {
        name: "Blizzard",
        type: "Logia",
        rarity: "Legendary",
        value: 2400000,
        permanentValue: 2880000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop",
        description: "A legendary Logia fruit that controls ice and snow."
      },
      {
        name: "Rumble",
        type: "Logia",
        rarity: "Legendary",
        value: 2100000,
        permanentValue: 2520000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1429552077091-836152271555?w=400&h=400&fit=crop",
        description: "A legendary Logia fruit that controls lightning."
      },
      {
        name: "Phoenix",
        type: "Zoan",
        rarity: "Legendary",
        value: 1800000,
        permanentValue: 2160000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1551419762-4858cf111790?w=400&h=400&fit=crop",
        description: "A legendary Zoan fruit that grants phoenix transformation and healing."
      },
      {
        name: "Buddha",
        type: "Zoan",
        rarity: "Legendary",
        value: 1200000,
        permanentValue: 1440000,
        demand: "Very High",
        imageUrl: "https://images.unsplash.com/photo-1544962503-4f22af1a24e6?w=400&h=400&fit=crop",
        description: "A legendary Zoan fruit that grants immense defensive capabilities."
      },
      {
        name: "Paw",
        type: "Paramecia",
        rarity: "Legendary",
        value: 2300000,
        permanentValue: 2760000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that repels anything it touches."
      },
      {
        name: "Gravity",
        type: "Paramecia",
        rarity: "Legendary",
        value: 2500000,
        permanentValue: 3000000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that manipulates gravitational forces."
      },
      {
        name: "Pain",
        type: "Paramecia",
        rarity: "Legendary",
        value: 2300000,
        permanentValue: 2760000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that manipulates pain and damage."
      },
      {
        name: "Quake",
        type: "Paramecia",
        rarity: "Legendary",
        value: 1000000,
        permanentValue: 1200000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that creates devastating earthquakes."
      },
      {
        name: "String",
        type: "Paramecia",
        rarity: "Legendary",
        value: 1800000,
        permanentValue: 2160000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that controls razor-sharp strings."
      },
      {
        name: "Portal",
        type: "Paramecia",
        rarity: "Legendary",
        value: 1900000,
        permanentValue: 2280000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A legendary fruit that creates dimensional portals."
      },
      
      // Epic Fruits
      {
        name: "Magma",
        type: "Logia",
        rarity: "Epic",
        value: 960000,
        permanentValue: 1152000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop",
        description: "An epic Logia fruit that controls molten lava."
      },
      {
        name: "Light",
        type: "Logia",
        rarity: "Epic",
        value: 650000,
        permanentValue: 780000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1429552077091-836152271555?w=400&h=400&fit=crop",
        description: "An epic Logia fruit that controls light beams."
      },
      {
        name: "Ice",
        type: "Logia",
        rarity: "Epic",
        value: 350000,
        permanentValue: 420000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop",
        description: "An epic Logia fruit that controls ice and frost."
      },
      {
        name: "Sand",
        type: "Logia",
        rarity: "Epic",
        value: 420000,
        permanentValue: 504000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop",
        description: "An epic Logia fruit that controls sand and deserts."
      },
      {
        name: "Dark",
        type: "Logia",
        rarity: "Epic",
        value: 500000,
        permanentValue: 600000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=400&fit=crop",
        description: "An epic Logia fruit that manipulates darkness."
      },
      {
        name: "Diamond",
        type: "Paramecia",
        rarity: "Epic",
        value: 600000,
        permanentValue: 720000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An epic fruit that transforms body parts into diamond."
      },
      {
        name: "Rubber",
        type: "Paramecia",
        rarity: "Epic",
        value: 750000,
        permanentValue: 900000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400&h=400&fit=crop",
        description: "An epic fruit that grants rubber-like properties."
      },
      {
        name: "Barrier",
        type: "Paramecia",
        rarity: "Epic",
        value: 800000,
        permanentValue: 960000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An epic fruit that creates protective barriers."
      },
      {
        name: "Magnet",
        type: "Paramecia",
        rarity: "Epic",
        value: 180000,
        permanentValue: 216000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An epic fruit that controls magnetic forces."
      },
      {
        name: "Door",
        type: "Paramecia",
        rarity: "Epic",
        value: 220000,
        permanentValue: 264000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An epic fruit that can open doors anywhere."
      },
      
      // Rare Fruits
      {
        name: "Flame",
        type: "Logia",
        rarity: "Rare",
        value: 250000,
        permanentValue: 300000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop",
        description: "A rare Logia fruit that controls fire and flames."
      },
      {
        name: "Smoke",
        type: "Logia",
        rarity: "Rare",
        value: 100000,
        permanentValue: 120000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=400&fit=crop",
        description: "A rare Logia fruit that controls smoke."
      },
      {
        name: "Falcon",
        type: "Zoan",
        rarity: "Rare",
        value: 300000,
        permanentValue: 360000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1551419762-4858cf111790?w=400&h=400&fit=crop",
        description: "A rare Zoan fruit that transforms into a falcon."
      },
      {
        name: "Bomb",
        type: "Paramecia",
        rarity: "Rare",
        value: 100000,
        permanentValue: 120000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A rare fruit that makes body parts explosive."
      },
      {
        name: "Spike",
        type: "Paramecia",
        rarity: "Rare",
        value: 180000,
        permanentValue: 216000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A rare fruit that creates sharp spikes."
      },
      {
        name: "Chop",
        type: "Paramecia",
        rarity: "Rare",
        value: 30000,
        permanentValue: 36000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A rare fruit that makes the user immune to swords."
      },
      {
        name: "Spring",
        type: "Paramecia",
        rarity: "Rare",
        value: 60000,
        permanentValue: 72000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400&h=400&fit=crop",
        description: "A rare fruit that turns body parts into springs."
      },
      
      // Uncommon Fruits
      {
        name: "Leopard",
        type: "Zoan",
        rarity: "Uncommon",
        value: 500000,
        permanentValue: 600000,
        demand: "High",
        imageUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=400&fit=crop",
        description: "An uncommon Zoan that grants leopard transformation."
      },
      {
        name: "Human",
        type: "Zoan",
        rarity: "Uncommon",
        value: 150000,
        permanentValue: 180000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=400&fit=crop",
        description: "An uncommon Zoan with human transformation."
      },
      {
        name: "Spin",
        type: "Paramecia",
        rarity: "Uncommon",
        value: 7500,
        permanentValue: 9000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An uncommon fruit that allows spinning attacks."
      },
      {
        name: "Kilo",
        type: "Paramecia",
        rarity: "Uncommon",
        value: 120000,
        permanentValue: 144000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "An uncommon fruit that controls body weight."
      },
      
      // Common Fruits
      {
        name: "Rocket",
        type: "Paramecia",
        rarity: "Common",
        value: 5000,
        permanentValue: 6000,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A common fruit with basic rocket abilities."
      },
      {
        name: "Love",
        type: "Paramecia",
        rarity: "Common",
        value: 23000,
        permanentValue: 27600,
        demand: "Low",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A common fruit that creates heart-shaped attacks."
      },
      {
        name: "Revive",
        type: "Paramecia",
        rarity: "Common",
        value: 55000,
        permanentValue: 66000,
        demand: "Medium",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=400&fit=crop",
        description: "A common fruit that can revive the user once."
      }
    ];

    fruitsData.forEach(fruit => {
      const id = randomUUID();
      this.fruits.set(id, { ...fruit, id });
    });

    // Initialize gamepasses data
    const gamepassesData: Omit<Gamepass, 'id'>[] = [
      {
        name: "2x Money",
        value: 1550000,
        description: "Doubles money gained from all sources"
      },
      {
        name: "2x Mastery",
        value: 1200000,
        description: "Doubles mastery gained from all sources"
      },
      {
        name: "Fast Boats",
        value: 450000,
        description: "Makes all boats significantly faster"
      },
      {
        name: "Fruit Notifier",
        value: 2700000,
        description: "Notifies when fruits spawn on the server"
      }
    ];

    gamepassesData.forEach(gamepass => {
      const id = randomUUID();
      this.gamepasses.set(id, { ...gamepass, id });
    });
  }

  async getAllFruits(): Promise<Fruit[]> {
    return Array.from(this.fruits.values());
  }

  async getFruitById(id: string): Promise<Fruit | undefined> {
    return this.fruits.get(id);
  }

  async getAllGamepasses(): Promise<Gamepass[]> {
    return Array.from(this.gamepasses.values());
  }

  async getGamepassById(id: string): Promise<Gamepass | undefined> {
    return this.gamepasses.get(id);
  }

  async searchFruits(query: string): Promise<Fruit[]> {
    const fruits = Array.from(this.fruits.values());
    return fruits.filter(fruit => 
      fruit.name.toLowerCase().includes(query.toLowerCase())
    );
  }

  async getFruitsByRarity(rarity: string): Promise<Fruit[]> {
    const fruits = Array.from(this.fruits.values());
    return fruits.filter(fruit => fruit.rarity === rarity);
  }

  async getPublicAPIData(): Promise<{ fruits: Fruit[], gamepasses: Gamepass[], lastUpdated: string, version: string }> {
    const fruits = await this.getAllFruits();
    const gamepasses = await this.getAllGamepasses();
    
    return {
      fruits,
      gamepasses,
      lastUpdated: new Date().toISOString(),
      version: "2.4.1",
    };
  }
}

export const storage = new MemStorage();
